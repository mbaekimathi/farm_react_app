// Test script to display age calculations for registered pigs
const mysql = require('mysql2/promise');
require('dotenv').config();

// Age calculation functions (same as backend)
function formatAge(days) {
  if (days < 7) {
    return `${days} day${days !== 1 ? 's' : ''}`;
  } else if (days < 30) {
    const weeks = Math.floor(days / 7);
    const remainingDays = days % 7;
    if (remainingDays === 0) {
      return `${weeks} week${weeks !== 1 ? 's' : ''}`;
    } else {
      return `${weeks} week${weeks !== 1 ? 's' : ''} ${remainingDays} day${remainingDays !== 1 ? 's' : ''}`;
    }
  } else if (days < 365) {
    const months = Math.floor(days / 30);
    const remainingDays = days % 30;
    if (remainingDays === 0) {
      return `${months} month${months !== 1 ? 's' : ''}`;
    } else {
      return `${months} month${months !== 1 ? 's' : ''} ${remainingDays} day${remainingDays !== 1 ? 's' : ''}`;
    }
  } else {
    const years = Math.floor(days / 365);
    const remainingDays = days % 365;
    if (remainingDays === 0) {
      return `${years} year${years !== 1 ? 's' : ''}`;
    } else {
      return `${years} year${years !== 1 ? 's' : ''} ${remainingDays} day${remainingDays !== 1 ? 's' : ''}`;
    }
  }
}

function getAgeCategory(days) {
  if (days <= 30) return 'newborn';
  if (days <= 90) return 'young';
  if (days <= 180) return 'adolescent';
  if (days <= 365) return 'adult';
  return 'mature';
}

async function displayAgeCalculations() {
  let connection;
  
  try {
    console.log('🔍 ========================================');
    console.log('📊 AGE CALCULATION DISPLAY');
    console.log('🔍 ========================================');
    console.log(`📅 Current Date: ${new Date().toISOString().split('T')[0]}`);
    console.log('🔍 ========================================');
    
    // Connect to database
    connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'kwetu_farm'
    });

    console.log('✅ Connected to database successfully');

    // Get all grown pigs with age calculation
    console.log('\n🐖 GROWN PIGS AGE CALCULATIONS:');
    console.log('----------------------------------------');
    const [grownPigs] = await connection.execute(`
      SELECT 
        pig_id, birth_date, weight, location, health_status,
        DATEDIFF(CURDATE(), birth_date) as age_in_days,
        FLOOR(DATEDIFF(CURDATE(), birth_date) / 7) as age_in_weeks,
        FLOOR(DATEDIFF(CURDATE(), birth_date) / 30) as age_in_months
      FROM grown_pigs 
      ORDER BY pig_id ASC
    `);
    
    if (grownPigs.length === 0) {
      console.log('   No grown pigs found in database');
    } else {
      grownPigs.forEach(pig => {
        const formattedAge = formatAge(pig.age_in_days);
        const ageCategory = getAgeCategory(pig.age_in_days);
        console.log(`   🐖 ${pig.pig_id}:`);
        console.log(`      📅 Birth: ${pig.birth_date} | Age: ${formattedAge} (${pig.age_in_days} days)`);
        console.log(`      🏷️ Category: ${ageCategory} | 📍 Location: ${pig.location}`);
        console.log(`      ⚖️ Weight: ${pig.weight}kg | 💚 Health: ${pig.health_status}`);
        console.log(`      📊 Weeks: ${pig.age_in_weeks} | 📊 Months: ${pig.age_in_months}`);
        console.log(`      ---`);
      });
    }
    
    // Get all litters with age calculation
    console.log('\n🐷 LITTERS AGE CALCULATIONS:');
    console.log('----------------------------------------');
    const [litters] = await connection.execute(`
      SELECT 
        litter_id, birth_date, total_born, male_count, female_count,
        average_weight, location, health_status,
        DATEDIFF(CURDATE(), birth_date) as age_in_days,
        FLOOR(DATEDIFF(CURDATE(), birth_date) / 7) as age_in_weeks,
        FLOOR(DATEDIFF(CURDATE(), birth_date) / 30) as age_in_months
      FROM litters 
      ORDER BY birth_date DESC
    `);
    
    if (litters.length === 0) {
      console.log('   No litters found in database');
    } else {
      litters.forEach(litter => {
        const formattedAge = formatAge(litter.age_in_days);
        const ageCategory = getAgeCategory(litter.age_in_days);
        console.log(`   🐷 ${litter.litter_id}:`);
        console.log(`      📅 Birth: ${litter.birth_date} | Age: ${formattedAge} (${litter.age_in_days} days)`);
        console.log(`      🏷️ Category: ${ageCategory} | 📍 Location: ${litter.location}`);
        console.log(`      🐖 Piglets: ${litter.total_born} (${litter.male_count}♂ ${litter.female_count}♀)`);
        console.log(`      ⚖️ Avg Weight: ${litter.average_weight}kg | 💚 Health: ${litter.health_status}`);
        console.log(`      📊 Weeks: ${litter.age_in_weeks} | 📊 Months: ${litter.age_in_months}`);
        console.log(`      ---`);
      });
    }
    
    // Get all batches with age calculation
    console.log('\n📦 BATCHES AGE CALCULATIONS:');
    console.log('----------------------------------------');
    const [batches] = await connection.execute(`
      SELECT 
        batch_id, average_birth_date, male_count, female_count,
        purpose, location, health_status,
        DATEDIFF(CURDATE(), average_birth_date) as age_in_days,
        FLOOR(DATEDIFF(CURDATE(), average_birth_date) / 7) as age_in_weeks,
        FLOOR(DATEDIFF(CURDATE(), average_birth_date) / 30) as age_in_months
      FROM batches 
      ORDER BY formation_date DESC
    `);
    
    if (batches.length === 0) {
      console.log('   No batches found in database');
    } else {
      batches.forEach(batch => {
        const formattedAge = formatAge(batch.age_in_days);
        const ageCategory = getAgeCategory(batch.age_in_days);
        console.log(`   📦 ${batch.batch_id}:`);
        console.log(`      📅 Avg Birth: ${batch.average_birth_date} | Age: ${formattedAge} (${batch.age_in_days} days)`);
        console.log(`      🏷️ Category: ${ageCategory} | 📍 Location: ${batch.location}`);
        console.log(`      🐖 Total: ${batch.male_count + batch.female_count} (${batch.male_count}♂ ${batch.female_count}♀)`);
        console.log(`      🎯 Purpose: ${batch.purpose} | 💚 Health: ${batch.health_status}`);
        console.log(`      📊 Weeks: ${batch.age_in_weeks} | 📊 Months: ${batch.age_in_months}`);
        console.log(`      ---`);
      });
    }
    
    // Summary statistics
    console.log('\n📈 AGE SUMMARY STATISTICS:');
    console.log('----------------------------------------');
    
    const totalGrownPigs = grownPigs.length;
    const totalLitters = litters.length;
    const totalBatches = batches.length;
    
    console.log(`🐖 Grown Pigs: ${totalGrownPigs}`);
    console.log(`🐷 Litters: ${totalLitters}`);
    console.log(`📦 Batches: ${totalBatches}`);
    console.log(`📊 Total Animals: ${totalGrownPigs + totalLitters + totalBatches}`);
    
    // Age category breakdown
    const allAnimals = [
      ...grownPigs.map(p => ({ type: 'grown', age: p.age_in_days, category: getAgeCategory(p.age_in_days) })),
      ...litters.map(l => ({ type: 'litter', age: l.age_in_days, category: getAgeCategory(l.age_in_days) })),
      ...batches.map(b => ({ type: 'batch', age: b.age_in_days, category: getAgeCategory(b.age_in_days) }))
    ];
    
    const newborn = allAnimals.filter(a => a.category === 'newborn').length;
    const young = allAnimals.filter(a => a.category === 'young').length;
    const adolescent = allAnimals.filter(a => a.category === 'adolescent').length;
    const adult = allAnimals.filter(a => a.category === 'adult').length;
    const mature = allAnimals.filter(a => a.category === 'mature').length;
    
    console.log('\n🏷️ Age Category Distribution:');
    console.log(`   👶 Newborn (0-30 days): ${newborn}`);
    console.log(`   🐣 Young (31-90 days): ${young}`);
    console.log(`   🐷 Adolescent (91-180 days): ${adolescent}`);
    console.log(`   🐖 Adult (181-365 days): ${adult}`);
    console.log(`   🐗 Mature (1+ years): ${mature}`);
    
    // Show some sample calculations
    console.log('\n🧮 SAMPLE AGE CALCULATIONS:');
    console.log('----------------------------------------');
    console.log('Test with different ages:');
    console.log(`   1 day: ${formatAge(1)}`);
    console.log(`   5 days: ${formatAge(5)}`);
    console.log(`   7 days: ${formatAge(7)}`);
    console.log(`   10 days: ${formatAge(10)}`);
    console.log(`   30 days: ${formatAge(30)}`);
    console.log(`   45 days: ${formatAge(45)}`);
    console.log(`   365 days: ${formatAge(365)}`);
    console.log(`   400 days: ${formatAge(400)}`);
    
    console.log('\n🔍 ========================================');
    console.log('✅ AGE CALCULATION DISPLAY COMPLETED');
    console.log('🔍 ========================================');
    
  } catch (error) {
    console.error('❌ Error displaying age calculations:', error.message);
  } finally {
    if (connection) {
      await connection.end();
      console.log('🔌 Database connection closed');
    }
  }
}

// Run the display
displayAgeCalculations(); 